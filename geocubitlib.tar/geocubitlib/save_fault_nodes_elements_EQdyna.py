#!python
#deal with mesh with split fault
# Opening fault cracks
# Input : surface up and down.
#
from __future__ import print_function

#import cubit
import sys
try:
    import start as start
    cubit = start.start_cubit()
except:
    try:
        import cubit
    except:
        print("error importing cubit, check if cubit is installed")
        pass

class fault_input:
    #list_vol1 is list of volumes to the left of surface and list_vol2 is list of volumes to the right
    def __init__(self,id,list_surface):
        self.id = id
        self.list_surface = list_surface
        self.name = 'MESH/fault_file_'+str(id)+'.dat'
        #save_cracks:get quad element number on fault
        quads_net_list = save_cracks(self.name,self.list_surface)
        #Unpacking list.
        dic_quads_all_list = unpack_list(quads_net_list,self.list_surface)

        print('len(quads):',len(dic_quads_all_list))

        save_elements_nodes(self.name,dic_quads_all_list)


def save_cracks(name,list_surface):
    quads_net_list = []
    for surface in list_surface   :
        #get a list of the number of quad element (a hex element is composed by 6 quads)
        quads_single_list = list(cubit.get_surface_quads(surface))
        quads_net_list.append(quads_single_list)
    # TO DO : stop python properly in case fault nodes at both sides
    #         do not match.
    #   if len(quads_fault_u) != len(quads_fault_d): stop
    #
    # SAVING FAULT ELEMENTS AND NODES
    return quads_net_list

def unpack_list(quads_net_list,list_surface):
    dic_quads_all_list = {}
    for i in range(0,len(quads_net_list)):
        surface=list_surface[i]
        el = list(quads_net_list[i])
        for j in el:
            dic_quads_all_list[j]=surface
    return dic_quads_all_list

def save_elements_nodes(name,dic_quads_all_list):
    print('')
    print('## save fault nodes elements: file = ',name)
    print('##')
    fault_file = open(name,'w')
    txt = ''
        #construct node dictionary 
        #key: slave node#, value: area,normal direction,master node# 
    dic_nodes = {}

    #cubit.cmd('set info off')
    #cubit.cmd('set echo off')
    #estimate mesh size

#put slave node information into dictionary
    for quad in dic_quads_all_list:
        # get surface# quad f belongs to
        surface=dic_quads_all_list[quad]
        nodes=cubit.get_connectivity('quad',quad)
        #calculate quad area
        if not len(nodes)==4:
             print('Node number in a quad is not 4')
             sys.exit('goodbye')
        else: 
             x1,y1,z1=cubit.get_nodal_coordinates(nodes[0])
             x2,y2,z2=cubit.get_nodal_coordinates(nodes[1])
             x3,y3,z3=cubit.get_nodal_coordinates(nodes[2])
             x4,y4,z4=cubit.get_nodal_coordinates(nodes[3])
             a1=( (x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2 ) ** 0.5
             b1=( (x3-x2)**2 + (y3-y2)**2 + (z3-z2)**2 ) ** 0.5
             c1=( (x4-x3)**2 + (y4-y3)**2 + (z4-z3)**2 ) ** 0.5
             d1=( (x1-x4)**2 + (y1-y4)**2 + (z1-z4)**2 ) ** 0.5 
             p1=( (x4-x2)**2 + (y4-y2)**2 + (z4-z2)**2 ) ** 0.5
             q1=( (x3-x1)**2 + (y3-y1)**2 + (z3-z1)**2 ) ** 0.5
             area=0.25 * (4.0*p1*p1*q1*q1 - (b1*b1 + d1*d1 - a1*a1 -c1*c1)**2)**0.5
                #put nodes in dictonary
        for node in nodes:
             if node not in dic_nodes.keys():
                 dic_nodes[node]=[]
                 dic_nodes[node].append(area)
                 x, y, z = cubit.get_nodal_coordinates(node)
                 v1,v2,v3=cubit.get_surface_normal_at_coord(surface,[x,y,z])
                 dic_nodes[node].append([v1,v2,v3])
                 #get mesh size
                 mesh_size=cubit.get_mesh_size('surface',surface)
                 #generate a virtal location mesh_size/100 away from the node, along surface normal direction
                 x_inc=x+v1*mesh_size/100.0
                 y_inc=y+v2*mesh_size/100.0
                 z_inc=z+v3*mesh_size/100.0
                 #dic_nodes[node].append([x_inc,y_inc,z_inc])
                 master_node=cubit.get_closest_node(x_inc,y_inc,z_inc)
                 #judge if the master has been found
                 if master_node!=0:
                     dic_nodes[node].append(master_node)
                 else:
                     print('No master node is found for node#: ',node)
                     #sys.exit('goodby')
             else:
                 dic_nodes[node][0]+=area


    #remove the nodes with slave node# equals master node#,incorrect code, dictionary can not change size during iteration
    num_split=0
    for key in dic_nodes:
        if key!=dic_nodes[key][2]:
            num_split+=1

    # number of slave nodes
    txt = '%10i\n' % (num_split)
    fault_file.write(txt)
    print('Number of nodes:',len(dic_nodes))
    #output the node infomation out 
    for key in dic_nodes:
        info=dic_nodes[key]
        #remove nodes on the boundary of surfaces, where slave node#= master node#
        if key!=info[2]:
        #slave node#,slave hex#,area,vector x,y,z,master node#
        #txt= '%10i %10.2f %10.5f %10.5f %10.5f %10.5f %10.5f %10.5f %10i \n' % (key,info[0],info[1][0],info[1][1],info[1][2],info[2][0],info[2][1],info[2][2],info[2])
            txt= '%10i %10.2f %12.6f %12.6f %12.6f %10i \n' % (key,info[0],info[1][0],info[1][1],info[1][2],info[2])
            fault_file.write(txt)
    #close the file
    fault_file.close()

    #cubit.cmd('set info on')
    #cubit.cmd('set echo on')

    print('## done fault file: ',name)
    print('')
