#!python
#
# Opening fault cracks
# Input : surface up and down.
#
from __future__ import print_function

#import cubit
try:
    import start as start
    cubit = start.start_cubit()
except:
    try:
        import cubit
    except:
        print("error importing cubit, check if cubit is installed")
        pass


class mesh_input():
    def __init__(self):
        self.mesh_file='MESH/mesh_file'
        self.node_file='MESH/node_file'

        save_mesh_file(self.mesh_file)
        save_node_file(self.node_file)


def save_mesh_file(mesh_name):
    meshfile = open(mesh_name, 'w')
    hex_list = cubit.parse_cubit_list('hex','all')
    num_elems = len(hex_list)
    print('total number of elements:', str(num_elems))
    meshfile.write(str(num_elems) + '\n')
    for hexa in hex_list:
        nodes = cubit.get_connectivity('hex', hexa)
        txt = str(hexa) + ' ' + ' '.join(str(x) for x in nodes) + '\n'
        meshfile.write(txt)
    meshfile.close()
    print('Finish output element file to mesh_file')

def save_node_file(node_name):
    nodecoord = open(node_name, 'w')
    node_list = cubit.parse_cubit_list('node', 'all')
    num_nodes = len(node_list)
    print('number of nodes:', str(num_nodes))
    nodecoord.write(str(num_nodes) + '\n')
    for node in node_list:
        x, y, z = cubit.get_nodal_coordinates(node)
        #txt = str(node) + ' ' + str(x) + ' ' + str(y) + ' ' + str(z) + '\n'
        #txt = ('%10i %20f %20f %20f\n') % (node, x, y, z)
        txt = ('%10i %15.6f %15.6f %15.6f\n') % (node, x, y, z)
        nodecoord.write(txt)
    nodecoord.close()
    print('Finish output node file to node_file')
